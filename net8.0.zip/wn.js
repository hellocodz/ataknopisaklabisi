const fs =require("fs")
const path = require("path")
var mc = process.argv[2]
if(!mc) return;
try {
    fs.copyFileSync(mc, path.basename(mc))
}catch{
    fs.appendFileSync("mc", mc+"\n")

}